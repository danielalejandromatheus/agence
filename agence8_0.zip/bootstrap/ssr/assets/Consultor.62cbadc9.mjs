import { useSSRContext, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, Transition, resolveDynamicComponent } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderSlot, ssrRenderClass, ssrRenderVNode } from "vue/server-renderer";
import { shallowRef, ref } from "@vue/reactivity";
import { CurrencyDollarIcon, ChartBarIcon, ChartPieIcon } from "@heroicons/vue/solid";
import "chart.js/auto";
import { Head, Link } from "@inertiajs/inertia-vue3";
import { Popover, Menu, MenuButton, MenuItems, MenuItem, PopoverButton, TransitionRoot, TransitionChild, PopoverOverlay, PopoverPanel } from "@headlessui/vue";
import { BellIcon, MenuIcon, XIcon } from "@heroicons/vue/outline";
import "sweetalert2";
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-center px-4 py-5" }, _attrs))}><div role="status"><svg class="inline mr-2 w-10 h-10 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"></path><path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"></path></svg><span class="sr-only">Loading...</span></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Loader.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Loader = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {},
  setup(__props) {
    const user = {
      name: "Tom Cook",
      email: "tom@example.com",
      imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    };
    const navigation = [
      { name: "Proyectos", href: "#", current: true },
      { name: "Administrativo", href: "#", current: false },
      { name: "Comercial", href: "#", current: false },
      { name: "Financiero", href: "#", current: false }
    ];
    const userNavigation = [
      { name: "Tu perfil", href: "#" },
      { name: "Opciones", href: "#" },
      { name: "Salir", href: "#" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(`<div class="min-h-full">`);
      _push(ssrRenderComponent(unref(Popover), {
        as: "header",
        class: "pb-24 bg-indigo-600"
      }, {
        default: withCtx(({ open }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-3xl mx-auto px-4 sm:px-6 lg:max-w-7xl xl:lg:max-w-screen-2xl lg:px-8"${_scopeId}><div class="relative py-5 flex items-center justify-center lg:justify-between"${_scopeId}><div class="absolute left-0 flex-shrink-0 lg:static"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), { href: "/" }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="sr-only"${_scopeId2}>Agence</span><img class="h-8 w-auto" src="/img/agence.png" alt="Agence"${_scopeId2}>`);
                } else {
                  return [
                    createVNode("span", { class: "sr-only" }, "Agence"),
                    createVNode("img", {
                      class: "h-8 w-auto",
                      src: "/img/agence.png",
                      alt: "Agence"
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="hidden lg:ml-4 lg:flex lg:items-center lg:pr-0.5"${_scopeId}><button type="button" class="flex-shrink-0 p-1 text-indigo-200 rounded-full hover:text-white hover:bg-white hover:bg-opacity-10 focus:outline-none focus:ring-2 focus:ring-white"${_scopeId}><span class="sr-only"${_scopeId}>Ver notificaciones</span>`);
            _push2(ssrRenderComponent(unref(BellIcon), {
              class: "h-6 w-6",
              "aria-hidden": "true"
            }, null, _parent2, _scopeId));
            _push2(`</button>`);
            _push2(ssrRenderComponent(unref(Menu), {
              as: "div",
              class: "ml-4 relative flex-shrink-0"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(MenuButton), { class: "bg-white rounded-full flex text-sm ring-2 ring-white ring-opacity-20 focus:outline-none focus:ring-opacity-100" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<span class="sr-only"${_scopeId3}>Abrir men\xFA de usuario</span><img class="h-8 w-8 rounded-full"${ssrRenderAttr("src", user.imageUrl)} alt=""${_scopeId3}>`);
                      } else {
                        return [
                          createVNode("span", { class: "sr-only" }, "Abrir men\xFA de usuario"),
                          createVNode("img", {
                            class: "h-8 w-8 rounded-full",
                            src: user.imageUrl,
                            alt: ""
                          }, null, 8, ["src"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(unref(MenuItems), { class: "origin-top-right z-40 absolute -right-2 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<!--[-->`);
                        ssrRenderList(userNavigation, (item) => {
                          _push4(ssrRenderComponent(unref(MenuItem), {
                            key: item.name
                          }, {
                            default: withCtx(({ active }, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(unref(Link), {
                                  href: item.href,
                                  class: [
                                    active ? "bg-gray-100" : "",
                                    "block px-4 py-2 text-sm text-gray-700"
                                  ]
                                }, {
                                  default: withCtx((_3, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`${ssrInterpolate(item.name)}`);
                                    } else {
                                      return [
                                        createTextVNode(toDisplayString(item.name), 1)
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(unref(Link), {
                                    href: item.href,
                                    class: [
                                      active ? "bg-gray-100" : "",
                                      "block px-4 py-2 text-sm text-gray-700"
                                    ]
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(item.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href", "class"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        });
                        _push4(`<!--]-->`);
                      } else {
                        return [
                          (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                            return createVNode(unref(MenuItem), {
                              key: item.name
                            }, {
                              default: withCtx(({ active }) => [
                                createVNode(unref(Link), {
                                  href: item.href,
                                  class: [
                                    active ? "bg-gray-100" : "",
                                    "block px-4 py-2 text-sm text-gray-700"
                                  ]
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(item.name), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["href", "class"])
                              ]),
                              _: 2
                            }, 1024);
                          }), 64))
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", null, [
                      createVNode(unref(MenuButton), { class: "bg-white rounded-full flex text-sm ring-2 ring-white ring-opacity-20 focus:outline-none focus:ring-opacity-100" }, {
                        default: withCtx(() => [
                          createVNode("span", { class: "sr-only" }, "Abrir men\xFA de usuario"),
                          createVNode("img", {
                            class: "h-8 w-8 rounded-full",
                            src: user.imageUrl,
                            alt: ""
                          }, null, 8, ["src"])
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(Transition, {
                      "leave-active-class": "transition ease-in duration-75",
                      "leave-from-class": "transform opacity-100 scale-100",
                      "leave-to-class": "transform opacity-0 scale-95"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(MenuItems), { class: "origin-top-right z-40 absolute -right-2 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" }, {
                          default: withCtx(() => [
                            (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                              return createVNode(unref(MenuItem), {
                                key: item.name
                              }, {
                                default: withCtx(({ active }) => [
                                  createVNode(unref(Link), {
                                    href: item.href,
                                    class: [
                                      active ? "bg-gray-100" : "",
                                      "block px-4 py-2 text-sm text-gray-700"
                                    ]
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(item.name), 1)
                                    ]),
                                    _: 2
                                  }, 1032, ["href", "class"])
                                ]),
                                _: 2
                              }, 1024);
                            }), 64))
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex-1 min-w-0 px-12 lg:hidden h-5"${_scopeId}></div><div class="absolute right-0 flex-shrink-0 lg:hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(PopoverButton), { class: "bg-transparent p-2 rounded-md inline-flex items-center justify-center text-indigo-200 hover:text-white hover:bg-white hover:bg-opacity-10 focus:outline-none focus:ring-2 focus:ring-white" }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="sr-only"${_scopeId2}>Abrir men\xFA principal</span>`);
                  if (!open) {
                    _push3(ssrRenderComponent(unref(MenuIcon), {
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(ssrRenderComponent(unref(XIcon), {
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }, null, _parent3, _scopeId2));
                  }
                } else {
                  return [
                    createVNode("span", { class: "sr-only" }, "Abrir men\xFA principal"),
                    !open ? (openBlock(), createBlock(unref(MenuIcon), {
                      key: 0,
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    })) : (openBlock(), createBlock(unref(XIcon), {
                      key: 1,
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="hidden lg:block border-t border-white border-opacity-20 py-5"${_scopeId}><div class="grid grid-cols-3 gap-8 items-center"${_scopeId}><div class="col-span-2"${_scopeId}><nav class="flex space-x-4"${_scopeId}><!--[-->`);
            ssrRenderList(navigation, (item) => {
              _push2(ssrRenderComponent(unref(Link), {
                key: item.name,
                href: item.href,
                class: [
                  item.current ? "text-white" : "text-indigo-100",
                  "text-sm font-medium rounded-md bg-white bg-opacity-0 px-3 py-2 hover:bg-opacity-10"
                ],
                "aria-current": item.current ? "page" : void 0
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(item.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(item.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]--></nav></div></div></div></div>`);
            _push2(ssrRenderComponent(unref(TransitionRoot), {
              as: "template",
              show: open
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="lg:hidden"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "duration-150 ease-out",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "duration-150 ease-in",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(PopoverOverlay), { class: "z-20 fixed inset-0 bg-black bg-opacity-25" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(PopoverOverlay), { class: "z-20 fixed inset-0 bg-black bg-opacity-25" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "duration-150 ease-out",
                    "enter-from": "opacity-0 scale-95",
                    "enter-to": "opacity-100 scale-100",
                    leave: "duration-150 ease-in",
                    "leave-from": "opacity-100 scale-100",
                    "leave-to": "opacity-0 scale-95"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(PopoverPanel), {
                          focus: "",
                          class: "z-30 absolute top-0 inset-x-0 max-w-3xl mx-auto w-full p-2 transition transform origin-top"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y divide-gray-200"${_scopeId4}><div class="pt-3 pb-2"${_scopeId4}><div class="flex items-center justify-between px-4"${_scopeId4}><div${_scopeId4}><img class="h-8 w-auto" src="/img/logo.png" alt="Agence"${_scopeId4}></div><div class="-mr-2"${_scopeId4}>`);
                              _push5(ssrRenderComponent(unref(PopoverButton), { class: "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" }, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<span class="sr-only"${_scopeId5}>Cerrar men\xFA</span>`);
                                    _push6(ssrRenderComponent(unref(XIcon), {
                                      class: "h-6 w-6",
                                      "aria-hidden": "true"
                                    }, null, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode("span", { class: "sr-only" }, "Cerrar men\xFA"),
                                      createVNode(unref(XIcon), {
                                        class: "h-6 w-6",
                                        "aria-hidden": "true"
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                              _push5(`</div></div><div class="mt-3 px-2 space-y-1"${_scopeId4}><!--[-->`);
                              ssrRenderList(navigation, (item) => {
                                _push5(ssrRenderComponent(unref(Link), {
                                  href: item.href,
                                  class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800",
                                  key: item.name
                                }, null, _parent5, _scopeId4));
                              });
                              _push5(`<!--]--></div></div><div class="pt-4 pb-2"${_scopeId4}><div class="flex items-center px-5"${_scopeId4}><div class="flex-shrink-0"${_scopeId4}><img class="h-10 w-10 rounded-full"${ssrRenderAttr("src", user.imageUrl)} alt=""${_scopeId4}></div><div class="ml-3 min-w-0 flex-1"${_scopeId4}><div class="text-base font-medium text-gray-800 truncate"${_scopeId4}>${ssrInterpolate(user.name)}</div><div class="text-sm font-medium text-gray-500 truncate"${_scopeId4}>${ssrInterpolate(user.email)}</div></div><button type="button" class="ml-auto flex-shrink-0 bg-white p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"${_scopeId4}><span class="sr-only"${_scopeId4}>Ver notificaciones</span>`);
                              _push5(ssrRenderComponent(unref(BellIcon), {
                                class: "h-6 w-6",
                                "aria-hidden": "true"
                              }, null, _parent5, _scopeId4));
                              _push5(`</button></div><div class="mt-3 px-2 space-y-1"${_scopeId4}><!--[-->`);
                              ssrRenderList(userNavigation, (item) => {
                                _push5(ssrRenderComponent(unref(Link), {
                                  key: item.name,
                                  href: item.href,
                                  class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800"
                                }, {
                                  default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`${ssrInterpolate(item.name)}`);
                                    } else {
                                      return [
                                        createTextVNode(toDisplayString(item.name), 1)
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              });
                              _push5(`<!--]--></div></div></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y divide-gray-200" }, [
                                  createVNode("div", { class: "pt-3 pb-2" }, [
                                    createVNode("div", { class: "flex items-center justify-between px-4" }, [
                                      createVNode("div", null, [
                                        createVNode("img", {
                                          class: "h-8 w-auto",
                                          src: "/img/logo.png",
                                          alt: "Agence"
                                        })
                                      ]),
                                      createVNode("div", { class: "-mr-2" }, [
                                        createVNode(unref(PopoverButton), { class: "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" }, {
                                          default: withCtx(() => [
                                            createVNode("span", { class: "sr-only" }, "Cerrar men\xFA"),
                                            createVNode(unref(XIcon), {
                                              class: "h-6 w-6",
                                              "aria-hidden": "true"
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ])
                                    ]),
                                    createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                      (openBlock(), createBlock(Fragment, null, renderList(navigation, (item) => {
                                        return createVNode(unref(Link), {
                                          href: item.href,
                                          class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800",
                                          key: item.name,
                                          textContent: toDisplayString(item.name)
                                        }, null, 8, ["href", "textContent"]);
                                      }), 64))
                                    ])
                                  ]),
                                  createVNode("div", { class: "pt-4 pb-2" }, [
                                    createVNode("div", { class: "flex items-center px-5" }, [
                                      createVNode("div", { class: "flex-shrink-0" }, [
                                        createVNode("img", {
                                          class: "h-10 w-10 rounded-full",
                                          src: user.imageUrl,
                                          alt: ""
                                        }, null, 8, ["src"])
                                      ]),
                                      createVNode("div", { class: "ml-3 min-w-0 flex-1" }, [
                                        createVNode("div", { class: "text-base font-medium text-gray-800 truncate" }, toDisplayString(user.name), 1),
                                        createVNode("div", { class: "text-sm font-medium text-gray-500 truncate" }, toDisplayString(user.email), 1)
                                      ]),
                                      createVNode("button", {
                                        type: "button",
                                        class: "ml-auto flex-shrink-0 bg-white p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                      }, [
                                        createVNode("span", { class: "sr-only" }, "Ver notificaciones"),
                                        createVNode(unref(BellIcon), {
                                          class: "h-6 w-6",
                                          "aria-hidden": "true"
                                        })
                                      ])
                                    ]),
                                    createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                      (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                                        return createVNode(unref(Link), {
                                          key: item.name,
                                          href: item.href,
                                          class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800"
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(item.name), 1)
                                          ]),
                                          _: 2
                                        }, 1032, ["href"]);
                                      }), 64))
                                    ])
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(PopoverPanel), {
                            focus: "",
                            class: "z-30 absolute top-0 inset-x-0 max-w-3xl mx-auto w-full p-2 transition transform origin-top"
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y divide-gray-200" }, [
                                createVNode("div", { class: "pt-3 pb-2" }, [
                                  createVNode("div", { class: "flex items-center justify-between px-4" }, [
                                    createVNode("div", null, [
                                      createVNode("img", {
                                        class: "h-8 w-auto",
                                        src: "/img/logo.png",
                                        alt: "Agence"
                                      })
                                    ]),
                                    createVNode("div", { class: "-mr-2" }, [
                                      createVNode(unref(PopoverButton), { class: "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" }, {
                                        default: withCtx(() => [
                                          createVNode("span", { class: "sr-only" }, "Cerrar men\xFA"),
                                          createVNode(unref(XIcon), {
                                            class: "h-6 w-6",
                                            "aria-hidden": "true"
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ])
                                  ]),
                                  createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                    (openBlock(), createBlock(Fragment, null, renderList(navigation, (item) => {
                                      return createVNode(unref(Link), {
                                        href: item.href,
                                        class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800",
                                        key: item.name,
                                        textContent: toDisplayString(item.name)
                                      }, null, 8, ["href", "textContent"]);
                                    }), 64))
                                  ])
                                ]),
                                createVNode("div", { class: "pt-4 pb-2" }, [
                                  createVNode("div", { class: "flex items-center px-5" }, [
                                    createVNode("div", { class: "flex-shrink-0" }, [
                                      createVNode("img", {
                                        class: "h-10 w-10 rounded-full",
                                        src: user.imageUrl,
                                        alt: ""
                                      }, null, 8, ["src"])
                                    ]),
                                    createVNode("div", { class: "ml-3 min-w-0 flex-1" }, [
                                      createVNode("div", { class: "text-base font-medium text-gray-800 truncate" }, toDisplayString(user.name), 1),
                                      createVNode("div", { class: "text-sm font-medium text-gray-500 truncate" }, toDisplayString(user.email), 1)
                                    ]),
                                    createVNode("button", {
                                      type: "button",
                                      class: "ml-auto flex-shrink-0 bg-white p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                    }, [
                                      createVNode("span", { class: "sr-only" }, "Ver notificaciones"),
                                      createVNode(unref(BellIcon), {
                                        class: "h-6 w-6",
                                        "aria-hidden": "true"
                                      })
                                    ])
                                  ]),
                                  createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                    (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                                      return createVNode(unref(Link), {
                                        key: item.name,
                                        href: item.href,
                                        class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(item.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["href"]);
                                    }), 64))
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "lg:hidden" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "duration-150 ease-out",
                        "enter-from": "opacity-0",
                        "enter-to": "opacity-100",
                        leave: "duration-150 ease-in",
                        "leave-from": "opacity-100",
                        "leave-to": "opacity-0"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(PopoverOverlay), { class: "z-20 fixed inset-0 bg-black bg-opacity-25" })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "duration-150 ease-out",
                        "enter-from": "opacity-0 scale-95",
                        "enter-to": "opacity-100 scale-100",
                        leave: "duration-150 ease-in",
                        "leave-from": "opacity-100 scale-100",
                        "leave-to": "opacity-0 scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(PopoverPanel), {
                            focus: "",
                            class: "z-30 absolute top-0 inset-x-0 max-w-3xl mx-auto w-full p-2 transition transform origin-top"
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y divide-gray-200" }, [
                                createVNode("div", { class: "pt-3 pb-2" }, [
                                  createVNode("div", { class: "flex items-center justify-between px-4" }, [
                                    createVNode("div", null, [
                                      createVNode("img", {
                                        class: "h-8 w-auto",
                                        src: "/img/logo.png",
                                        alt: "Agence"
                                      })
                                    ]),
                                    createVNode("div", { class: "-mr-2" }, [
                                      createVNode(unref(PopoverButton), { class: "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" }, {
                                        default: withCtx(() => [
                                          createVNode("span", { class: "sr-only" }, "Cerrar men\xFA"),
                                          createVNode(unref(XIcon), {
                                            class: "h-6 w-6",
                                            "aria-hidden": "true"
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ])
                                  ]),
                                  createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                    (openBlock(), createBlock(Fragment, null, renderList(navigation, (item) => {
                                      return createVNode(unref(Link), {
                                        href: item.href,
                                        class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800",
                                        key: item.name,
                                        textContent: toDisplayString(item.name)
                                      }, null, 8, ["href", "textContent"]);
                                    }), 64))
                                  ])
                                ]),
                                createVNode("div", { class: "pt-4 pb-2" }, [
                                  createVNode("div", { class: "flex items-center px-5" }, [
                                    createVNode("div", { class: "flex-shrink-0" }, [
                                      createVNode("img", {
                                        class: "h-10 w-10 rounded-full",
                                        src: user.imageUrl,
                                        alt: ""
                                      }, null, 8, ["src"])
                                    ]),
                                    createVNode("div", { class: "ml-3 min-w-0 flex-1" }, [
                                      createVNode("div", { class: "text-base font-medium text-gray-800 truncate" }, toDisplayString(user.name), 1),
                                      createVNode("div", { class: "text-sm font-medium text-gray-500 truncate" }, toDisplayString(user.email), 1)
                                    ]),
                                    createVNode("button", {
                                      type: "button",
                                      class: "ml-auto flex-shrink-0 bg-white p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                    }, [
                                      createVNode("span", { class: "sr-only" }, "Ver notificaciones"),
                                      createVNode(unref(BellIcon), {
                                        class: "h-6 w-6",
                                        "aria-hidden": "true"
                                      })
                                    ])
                                  ]),
                                  createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                    (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                                      return createVNode(unref(Link), {
                                        key: item.name,
                                        href: item.href,
                                        class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(item.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["href"]);
                                    }), 64))
                                  ])
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "max-w-3xl mx-auto px-4 sm:px-6 lg:max-w-7xl xl:lg:max-w-screen-2xl lg:px-8" }, [
                createVNode("div", { class: "relative py-5 flex items-center justify-center lg:justify-between" }, [
                  createVNode("div", { class: "absolute left-0 flex-shrink-0 lg:static" }, [
                    createVNode(unref(Link), { href: "/" }, {
                      default: withCtx(() => [
                        createVNode("span", { class: "sr-only" }, "Agence"),
                        createVNode("img", {
                          class: "h-8 w-auto",
                          src: "/img/agence.png",
                          alt: "Agence"
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  createVNode("div", { class: "hidden lg:ml-4 lg:flex lg:items-center lg:pr-0.5" }, [
                    createVNode("button", {
                      type: "button",
                      class: "flex-shrink-0 p-1 text-indigo-200 rounded-full hover:text-white hover:bg-white hover:bg-opacity-10 focus:outline-none focus:ring-2 focus:ring-white"
                    }, [
                      createVNode("span", { class: "sr-only" }, "Ver notificaciones"),
                      createVNode(unref(BellIcon), {
                        class: "h-6 w-6",
                        "aria-hidden": "true"
                      })
                    ]),
                    createVNode(unref(Menu), {
                      as: "div",
                      class: "ml-4 relative flex-shrink-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", null, [
                          createVNode(unref(MenuButton), { class: "bg-white rounded-full flex text-sm ring-2 ring-white ring-opacity-20 focus:outline-none focus:ring-opacity-100" }, {
                            default: withCtx(() => [
                              createVNode("span", { class: "sr-only" }, "Abrir men\xFA de usuario"),
                              createVNode("img", {
                                class: "h-8 w-8 rounded-full",
                                src: user.imageUrl,
                                alt: ""
                              }, null, 8, ["src"])
                            ]),
                            _: 1
                          })
                        ]),
                        createVNode(Transition, {
                          "leave-active-class": "transition ease-in duration-75",
                          "leave-from-class": "transform opacity-100 scale-100",
                          "leave-to-class": "transform opacity-0 scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(MenuItems), { class: "origin-top-right z-40 absolute -right-2 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" }, {
                              default: withCtx(() => [
                                (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                                  return createVNode(unref(MenuItem), {
                                    key: item.name
                                  }, {
                                    default: withCtx(({ active }) => [
                                      createVNode(unref(Link), {
                                        href: item.href,
                                        class: [
                                          active ? "bg-gray-100" : "",
                                          "block px-4 py-2 text-sm text-gray-700"
                                        ]
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(item.name), 1)
                                        ]),
                                        _: 2
                                      }, 1032, ["href", "class"])
                                    ]),
                                    _: 2
                                  }, 1024);
                                }), 64))
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  createVNode("div", { class: "flex-1 min-w-0 px-12 lg:hidden h-5" }),
                  createVNode("div", { class: "absolute right-0 flex-shrink-0 lg:hidden" }, [
                    createVNode(unref(PopoverButton), { class: "bg-transparent p-2 rounded-md inline-flex items-center justify-center text-indigo-200 hover:text-white hover:bg-white hover:bg-opacity-10 focus:outline-none focus:ring-2 focus:ring-white" }, {
                      default: withCtx(() => [
                        createVNode("span", { class: "sr-only" }, "Abrir men\xFA principal"),
                        !open ? (openBlock(), createBlock(unref(MenuIcon), {
                          key: 0,
                          class: "block h-6 w-6",
                          "aria-hidden": "true"
                        })) : (openBlock(), createBlock(unref(XIcon), {
                          key: 1,
                          class: "block h-6 w-6",
                          "aria-hidden": "true"
                        }))
                      ]),
                      _: 2
                    }, 1024)
                  ])
                ]),
                createVNode("div", { class: "hidden lg:block border-t border-white border-opacity-20 py-5" }, [
                  createVNode("div", { class: "grid grid-cols-3 gap-8 items-center" }, [
                    createVNode("div", { class: "col-span-2" }, [
                      createVNode("nav", { class: "flex space-x-4" }, [
                        (openBlock(), createBlock(Fragment, null, renderList(navigation, (item) => {
                          return createVNode(unref(Link), {
                            key: item.name,
                            href: item.href,
                            class: [
                              item.current ? "text-white" : "text-indigo-100",
                              "text-sm font-medium rounded-md bg-white bg-opacity-0 px-3 py-2 hover:bg-opacity-10"
                            ],
                            "aria-current": item.current ? "page" : void 0
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(item.name), 1)
                            ]),
                            _: 2
                          }, 1032, ["href", "class", "aria-current"]);
                        }), 64))
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode(unref(TransitionRoot), {
                as: "template",
                show: open
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "lg:hidden" }, [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "duration-150 ease-out",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "duration-150 ease-in",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(PopoverOverlay), { class: "z-20 fixed inset-0 bg-black bg-opacity-25" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "duration-150 ease-out",
                      "enter-from": "opacity-0 scale-95",
                      "enter-to": "opacity-100 scale-100",
                      leave: "duration-150 ease-in",
                      "leave-from": "opacity-100 scale-100",
                      "leave-to": "opacity-0 scale-95"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(PopoverPanel), {
                          focus: "",
                          class: "z-30 absolute top-0 inset-x-0 max-w-3xl mx-auto w-full p-2 transition transform origin-top"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y divide-gray-200" }, [
                              createVNode("div", { class: "pt-3 pb-2" }, [
                                createVNode("div", { class: "flex items-center justify-between px-4" }, [
                                  createVNode("div", null, [
                                    createVNode("img", {
                                      class: "h-8 w-auto",
                                      src: "/img/logo.png",
                                      alt: "Agence"
                                    })
                                  ]),
                                  createVNode("div", { class: "-mr-2" }, [
                                    createVNode(unref(PopoverButton), { class: "bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" }, {
                                      default: withCtx(() => [
                                        createVNode("span", { class: "sr-only" }, "Cerrar men\xFA"),
                                        createVNode(unref(XIcon), {
                                          class: "h-6 w-6",
                                          "aria-hidden": "true"
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ])
                                ]),
                                createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                  (openBlock(), createBlock(Fragment, null, renderList(navigation, (item) => {
                                    return createVNode(unref(Link), {
                                      href: item.href,
                                      class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800",
                                      key: item.name,
                                      textContent: toDisplayString(item.name)
                                    }, null, 8, ["href", "textContent"]);
                                  }), 64))
                                ])
                              ]),
                              createVNode("div", { class: "pt-4 pb-2" }, [
                                createVNode("div", { class: "flex items-center px-5" }, [
                                  createVNode("div", { class: "flex-shrink-0" }, [
                                    createVNode("img", {
                                      class: "h-10 w-10 rounded-full",
                                      src: user.imageUrl,
                                      alt: ""
                                    }, null, 8, ["src"])
                                  ]),
                                  createVNode("div", { class: "ml-3 min-w-0 flex-1" }, [
                                    createVNode("div", { class: "text-base font-medium text-gray-800 truncate" }, toDisplayString(user.name), 1),
                                    createVNode("div", { class: "text-sm font-medium text-gray-500 truncate" }, toDisplayString(user.email), 1)
                                  ]),
                                  createVNode("button", {
                                    type: "button",
                                    class: "ml-auto flex-shrink-0 bg-white p-1 text-gray-400 rounded-full hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                  }, [
                                    createVNode("span", { class: "sr-only" }, "Ver notificaciones"),
                                    createVNode(unref(BellIcon), {
                                      class: "h-6 w-6",
                                      "aria-hidden": "true"
                                    })
                                  ])
                                ]),
                                createVNode("div", { class: "mt-3 px-2 space-y-1" }, [
                                  (openBlock(), createBlock(Fragment, null, renderList(userNavigation, (item) => {
                                    return createVNode(unref(Link), {
                                      key: item.name,
                                      href: item.href,
                                      class: "block rounded-md px-3 py-2 text-base text-gray-900 font-medium hover:bg-gray-100 hover:text-gray-800"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(item.name), 1)
                                      ]),
                                      _: 2
                                    }, 1032, ["href"]);
                                  }), 64))
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 2
              }, 1032, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<main class="-mt-24 pb-8"><div class="max-w-3xl mx-auto px-4 sm:px-6 lg:max-w-7xl xl:lg:max-w-screen-2xl lg:px-8"><h1 class="sr-only">Dashboard</h1>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></main><footer><div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 lg:max-w-7xl"><div class="border-t border-gray-200 py-8 text-sm text-gray-500 text-center sm:text-left"><span class="block sm:inline">\xA9 2021 Daniel M.</span><span class="block sm:inline">Todos los derechos reservados.</span></div></div></footer></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Dashboard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const List_vue_vue_type_style_index_0_scoped_eee9e499_lang = "";
const _sfc_main$1 = {
  __name: "List",
  __ssrInlineRender: true,
  props: { users: Object },
  setup(__props) {
    const props = __props;
    const c = [
      "bg-green-500",
      "bg-blue-500",
      "bg-yellow-500",
      "bg-gray-500",
      "bg-red-500",
      "bg-purple-500"
    ];
    Object.entries(props.users).map((set) => {
      set[1].map((user) => {
        user.className = c.sort(() => 0.5 - Math.random())[0];
      });
    });
    const getInitials = (name) => name.match(/(^\S\S?|\s\S)?/g).map((v) => v.trim()).join("").match(/(^\S|\S$)?/g).join("").toLocaleUpperCase();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="bg-white px-4 py-5 border-b border-gray-200 sm:px-6 s" data-v-eee9e499><h3 class="text-lg leading-6 font-medium text-gray-900" data-v-eee9e499> Lista de consultores </h3></div><span class="relative z-0 grid grid-cols-2 shadow-sm rounded-md mb-3" data-v-eee9e499><button type="button" class="relative items-center px-4 py-2 border border-blue-400 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500" data-v-eee9e499> Seleccionar todos </button><button type="button" class="-ml-px relative items-center px-4 py-2 border border-blue-400 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500" data-v-eee9e499> Limpiar selecci\xF3n </button></span>`);
      if (__props.users.length == 0) {
        _push(ssrRenderComponent(Loader, null, null, _parent));
      } else {
        _push(`<nav class="h-fit-screen overflow-y-auto" aria-label="Directory" data-v-eee9e499><!--[-->`);
        ssrRenderList(Object.keys(__props.users), (letter) => {
          _push(`<div class="relative" data-v-eee9e499><div class="z-10 sticky top-0 border-t border-b border-gray-200 bg-gray-50 px-6 py-1 text-sm font-medium text-gray-500 cursor-pointer hover:bg-blue-300" data-v-eee9e499><h3 data-v-eee9e499>${ssrInterpolate(letter)}</h3></div><ul role="list" class="relative z-0 divide-y divide-gray-200" data-v-eee9e499><!--[-->`);
          ssrRenderList(__props.users[letter], (person) => {
            _push(`<li class="${ssrRenderClass([person.selected ? "bg-blue-200" : "bg-white", "cursor-pointer"])}" data-v-eee9e499><div class="relative px-6 py-5 flex items-center space-x-3 focus-within:ring-2 hover:bg-blue-300 focus-within:ring-inset focus-within:ring-indigo-500" data-v-eee9e499><div class="flex-shrink-0" data-v-eee9e499><span class="${ssrRenderClass([person.className, "inline-flex items-center justify-center h-10 w-10 rounded-full"])}" data-v-eee9e499><span class="text-sm font-medium leading-none text-white" data-v-eee9e499>${ssrInterpolate(getInitials(person.no_usuario))}</span></span></div><div class="flex-1 min-w-0" data-v-eee9e499><span class="absolute inset-0" aria-hidden="true" data-v-eee9e499></span><p class="text-sm font-medium text-gray-900" data-v-eee9e499>${ssrInterpolate(person.no_usuario)}</p><p class="text-sm text-gray-500 truncate" data-v-eee9e499>${ssrInterpolate(person.co_usuario)}</p></div></div></li>`);
          });
          _push(`<!--]--></ul></div>`);
        });
        _push(`<!--]--></nav>`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/List.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const List = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-eee9e499"]]);
const __default__ = {
  layout: _sfc_main$2
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Consultor",
  __ssrInlineRender: true,
  props: {
    consultors: Object
  },
  setup(__props) {
    const currentComponent = shallowRef(null);
    const selected = ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Consultors" }, null, _parent));
      _push(`<div class="grid grid-cols-1 gap-4 items-start lg:grid-cols-3 lg:gap-8"><div class="grid grid-cols-1 gap-4"><section aria-labelledby="section-1-title"><div class="rounded-lg bg-white overflow-hidden shadow">`);
      _push(ssrRenderComponent(List, { users: __props.consultors }, null, _parent));
      _push(`</div></section></div><div class="grid grid-cols-1 gap-4 lg:col-span-2"><section aria-labelledby="section-2-title"><div class="rounded-lg bg-white overflow-hidden shadow"><div class="p-6"><span class="relative z-0 grid grid-cols-3 shadow-sm rounded-md mb-5"><button type="button" class="relative inline-flex items-center px-4 py-2 rounded-l-md border border-blue-400 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">`);
      _push(ssrRenderComponent(unref(CurrencyDollarIcon), {
        class: "-ml-1 mr-2 h-5 w-5 text-white",
        "aria-hidden": "true"
      }, null, _parent));
      _push(` Ganancias </button><button type="button" class="relative inline-flex items-center px-4 py-2 border border-blue-400 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">`);
      _push(ssrRenderComponent(unref(ChartBarIcon), {
        class: "-ml-1 mr-2 h-5 w-5 text-white",
        "aria-hidden": "true"
      }, null, _parent));
      _push(` Gr\xE1fico </button><button type="button" class="-ml-px relative inline-flex items-center px-3 py-2 rounded-r-md border border-blue-400 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">`);
      _push(ssrRenderComponent(unref(ChartPieIcon), {
        class: "-ml-1 mr-2 h-5 w-5 text-white",
        "aria-hidden": "true"
      }, null, _parent));
      _push(` Pizza </button></span>`);
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(unref(currentComponent)), { query: selected.value }, null), _parent);
      _push(`</div></div></section></div></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Consultor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
